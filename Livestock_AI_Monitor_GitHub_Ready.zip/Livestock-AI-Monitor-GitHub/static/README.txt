The dashboard stylesheet is style.css.
Optional: place your own Kannada alert recording at alert_kn.mp3 if you have permission to use/share it.
Do not commit private recordings or personal data without consent.
