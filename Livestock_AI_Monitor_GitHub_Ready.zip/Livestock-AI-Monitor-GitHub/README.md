# Livestock AI Monitor — Hackathon MVP

**Theme:** AI / Smart Agriculture and Animal Husbandry  
**Problem statement:** AI-Based Early Disease Detection in Livestock  
**Team:** Syntax Error

A Flask-based hackathon prototype that combines uploaded-photo livestock object detection with a dashboard demonstrating an early-warning workflow. It is a proof of concept, not a veterinary diagnostic tool.

## Current prototype

- Upload a photo and run YOLO-based object detection for classes supported by the configured model.
- Show bounding boxes, labels, confidence values, and an estimated count.
- Display a dashboard with 12 simulated animal profiles and a demo risk score/anomaly flag.
- Simulate an abnormal condition and reset the demo data.
- Includes an optional Twilio outbound-call route. It requires valid credentials, an accessible HTTPS base URL, and Twilio account/phone configuration.
- Live camera is a preview only. Video detection is intentionally not included.

## Important limitations

- Photo detection is object detection, **not disease diagnosis**.
- The default general-purpose model does not reliably distinguish every livestock species. In particular, a generic `bird` class does not confirm a hen.
- Exact counts are not guaranteed, especially for crowded, small, blurry, or partly hidden animals. A livestock-specific model must be trained/evaluated on labelled images for dependable species-level counting.
- Temperature, movement, and feeding values in the dashboard are simulated; no physical sensors are connected.
- The risk score and anomaly flag are demo-only and are not clinically validated.
- The phone-call feature is optional and will not work until properly configured. Kannada playback requires your own `static/alert_kn.mp3` recording; otherwise the endpoint uses its built-in English fallback.

## Requirements

- Python 3.10 or newer
- Internet connection for first-time package/model downloads
- Optional: a Twilio account and publicly reachable HTTPS URL to test real outbound calls

## Run locally

1. Create and activate a virtual environment:

   **Windows (PowerShell)**
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

2. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```

3. Start the web app:
   ```bash
   python app.py
   ```

4. Open `http://127.0.0.1:5000` in your browser.

5. On first photo detection, the YOLO weights may download automatically. This can take time and needs an internet connection.

## Optional Twilio call setup

1. Copy `.env.example` to a local file named `.env`.
2. Fill in your own `PUBLIC_BASE_URL`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER`, and `FARMER_PHONE_NUMBER` values.
3. Ensure the public URL points to the currently running app, such as your active HTTPS ngrok URL.
4. Restart the Flask app after changing `.env`.

**Never upload `.env`, API keys, account SIDs combined with secrets, phone numbers, or other credentials to GitHub.** The `.gitignore` excludes `.env` by default. If a credential was exposed publicly, revoke/rotate it.

## Repository layout

```text
Livestock-AI-Monitor/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── README.txt
```

## For the hackathon submission

Upload the **source files** to GitHub, not just a ZIP archive. Submit the GitHub repository URL in the required form and upload the PowerPoint separately where the form asks for it. Set the repository to Public if the organisers need to inspect it and their rules allow public repositories.

## Credits / technology

- Python and Flask — backend and web routes
- HTML, CSS, JavaScript — browser dashboard
- Ultralytics YOLO — object detection
- OpenCV — image handling and bounding-box annotation
- NumPy and scikit-learn Isolation Forest — demo risk/anomaly workflow
- Twilio REST API — optional outbound call integration
